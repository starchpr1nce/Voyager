//
//  GameResult.swift
//  dices
//
//  Created by mnats on 20.11.2023.
//

//MARK: - UPDATE

enum GameResult: String {
    case win = "Win"
    case lose = "Lose"
    case draw = "Retry"
}
