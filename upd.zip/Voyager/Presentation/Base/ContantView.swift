//
//  ContantView.swift
//  Voyager
//
//  Created by admin on 20.11.2023.
//

import SwiftUI
import UIPilot

struct ContantView: View {
//    @StateObject var pilot = UIPilot(initial: PilotStringRoutes.main.value)
//    @StateObject var gameRouter = GameStateRoute(route: )
//    let viewModelFactory = ViewModelFactory()
    
    var body: some View {
        AppRouter()
//        UIPilotHost(pilot) { route in
//            switch route {
//            case PilotStringRoutes.onboarding.value:
//                OnboardingView().environmentObject(viewModelFactory.makeOnboardingViewModel())
//            case PilotStringRoutes.main.value:
//                MainView().environmentObject(viewModelFactory.makeMainViewModel())
//            case PilotStringRoutes.info.value:
//                InfoView().environmentObject(viewModelFactory.makeInfoViewModel())
//            case PilotStringRoutes.settings.value:
//                SettingsView().environmentObject(viewModelFactory.makeSettingsViewModel())
//            case PilotStringRoutes.gameWheel.value:
//                WheelView().environmentObject(viewModelFactory.makeGameWheelViewModel())
//            case PilotStringRoutes.gameWheelComplicated.value:
//                WheelComplicatedView().environmentObject(viewModelFactory.makeGameWheelComplicatedViewModel())
//            default:
//                EmptyView()
//            }
//        }
    }
}

//#Preview {
//    ContantView()
//}
