//
//  Constant.swift
//  Voyager
//
//  Created by admin on 06.12.2023.
//
//MARK: - Upd

import Foundation

struct Constant {
    
    static var delay: UInt64 = UInt64(StorageManager.shared.textSpeed)
//    static var delay: UInt64 = 1_000_000
    
}
